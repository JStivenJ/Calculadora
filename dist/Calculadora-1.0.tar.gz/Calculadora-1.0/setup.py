from setuptools import setup

setup(
      name = "Calculadora",
      version = "1.0",
      description = "Paquete calculadora con las operaciones básicas",
      author = "Julian Stiven Jimenez Uribe",
      author_email = "jsjimenezu@unal.edu.co",
      packages = ["Calculadora"])